import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import itertools
import math
import pandas as pd
from model.GNN import GCN, GraphSAGE, Res_SAGE

BN_MOMENTUM = 0.1


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes, momentum=BN_MOMENTUM)
        self.conv3 = nn.Conv2d(planes, planes * self.expansion, kernel_size=1,
                               bias=False)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion,
                                  momentum=BN_MOMENTUM)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class StageModule(nn.Module):
    def __init__(self, input_branches, output_branches, c):
        """
        构建对应stage，即用来融合不同尺度的实现
        :param input_branches: 输入的分支数，每个分支对应一种尺度
        :param output_branches: 输出的分支数
        :param c: 输入的第一个分支通道数
        """
        super().__init__()
        self.input_branches = input_branches
        self.output_branches = output_branches

        self.branches = nn.ModuleList()
        for i in range(self.input_branches):  # 每个分支上都先通过4个BasicBlock
            w = c * (2 ** i)  # 对应第i个分支的通道数
            branch = nn.Sequential(
                BasicBlock(w, w),
                BasicBlock(w, w),
                BasicBlock(w, w),
                BasicBlock(w, w)
            )
            self.branches.append(branch)

        self.fuse_layers = nn.ModuleList()  # 用于融合每个分支上的输出
        for i in range(self.output_branches):
            self.fuse_layers.append(nn.ModuleList())
            for j in range(self.input_branches):
                if i == j:
                    # 当输入、输出为同一个分支时不做任何处理
                    self.fuse_layers[-1].append(nn.Identity())
                elif i < j:
                    # 当输入分支j大于输出分支i时(即输入分支下采样率大于输出分支下采样率)，
                    # 此时需要对输入分支j进行通道调整以及上采样，方便后续相加
                    self.fuse_layers[-1].append(
                        nn.Sequential(
                            nn.Conv2d(c * (2 ** j), c * (2 ** i), kernel_size=1, stride=1, bias=False),
                            nn.BatchNorm2d(c * (2 ** i), momentum=BN_MOMENTUM),
                            nn.Upsample(scale_factor=2.0 ** (j - i), mode='nearest')
                        )
                    )
                else:  # i > j
                    # 当输入分支j小于输出分支i时(即输入分支下采样率小于输出分支下采样率)，
                    # 此时需要对输入分支j进行通道调整以及下采样，方便后续相加
                    # 注意，这里每次下采样2x都是通过一个3x3卷积层实现的，4x就是两个，8x就是三个，总共i-j个
                    ops = []
                    # 前i-j-1个卷积层不用变通道，只进行下采样
                    for k in range(i - j - 1):
                        ops.append(
                            nn.Sequential(
                                nn.Conv2d(c * (2 ** j), c * (2 ** j), kernel_size=3, stride=2, padding=1, bias=False),
                                nn.BatchNorm2d(c * (2 ** j), momentum=BN_MOMENTUM),
                                nn.ReLU(inplace=True)
                            )
                        )
                    # 最后一个卷积层不仅要调整通道，还要进行下采样
                    ops.append(
                        nn.Sequential(
                            nn.Conv2d(c * (2 ** j), c * (2 ** i), kernel_size=3, stride=2, padding=1, bias=False),
                            nn.BatchNorm2d(c * (2 ** i), momentum=BN_MOMENTUM)
                        )
                    )
                    self.fuse_layers[-1].append(nn.Sequential(*ops))

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # 每个分支通过对应的block
        x = [branch(xi) for branch, xi in zip(self.branches, x)]

        # 接着融合不同尺寸信息
        x_fused = []
        for i in range(len(self.fuse_layers)):
            x_fused.append(
                self.relu(
                    sum([self.fuse_layers[i][j](x[j]) for j in range(len(self.branches))])
                )
            )

        return x_fused



class HighResolutionNet(nn.Module):
    def __init__(self, base_channel: int = 32, num_joints: int = 17, normalize_heatmap=True, group_mode="sum", norm_scale=1.0):
        super().__init__()
        # Stem
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64, momentum=BN_MOMENTUM)
        self.conv2 = nn.Conv2d(64, 64, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(64, momentum=BN_MOMENTUM)
        self.relu = nn.ReLU(inplace=True)

        # Stage1
        downsample = nn.Sequential(
            nn.Conv2d(64, 256, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(256, momentum=BN_MOMENTUM)
        )
        self.layer1 = nn.Sequential(
            Bottleneck(64, 64, downsample=downsample),
            Bottleneck(256, 64),
            Bottleneck(256, 64),
            Bottleneck(256, 64)
        )

        self.transition1 = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(256, base_channel, kernel_size=3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(base_channel, momentum=BN_MOMENTUM),
                nn.ReLU(inplace=True)
            ),
            nn.Sequential(
                nn.Sequential(  # 这里又使用一次Sequential是为了适配原项目中提供的权重
                    nn.Conv2d(256, base_channel * 2, kernel_size=3, stride=2, padding=1, bias=False),
                    nn.BatchNorm2d(base_channel * 2, momentum=BN_MOMENTUM),
                    nn.ReLU(inplace=True)
                )
            )
        ])

        # Stage2
        self.stage2 = nn.Sequential(
            StageModule(input_branches=2, output_branches=2, c=base_channel)
        )

        # transition2
        self.transition2 = nn.ModuleList([
            nn.Identity(),  # None,  - Used in place of "None" because it is callable
            nn.Identity(),  # None,  - Used in place of "None" because it is callable
            nn.Sequential(
                nn.Sequential(
                    nn.Conv2d(base_channel * 2, base_channel * 4, kernel_size=3, stride=2, padding=1, bias=False),
                    nn.BatchNorm2d(base_channel * 4, momentum=BN_MOMENTUM),
                    nn.ReLU(inplace=True)
                )
            )
        ])

        # Stage3
        self.stage3 = nn.Sequential(
            StageModule(input_branches=3, output_branches=3, c=base_channel),
            StageModule(input_branches=3, output_branches=3, c=base_channel),
            StageModule(input_branches=3, output_branches=3, c=base_channel),
            StageModule(input_branches=3, output_branches=3, c=base_channel)
        )

        # transition3
        self.transition3 = nn.ModuleList([
            nn.Identity(),  # None,  - Used in place of "None" because it is callable
            nn.Identity(),  # None,  - Used in place of "None" because it is callable
            nn.Identity(),  # None,  - Used in place of "None" because it is callable
            nn.Sequential(
                nn.Sequential(
                    nn.Conv2d(base_channel * 4, base_channel * 8, kernel_size=3, stride=2, padding=1, bias=False),
                    nn.BatchNorm2d(base_channel * 8, momentum=BN_MOMENTUM),
                    nn.ReLU(inplace=True)
                )
            )
        ])

        # Stage4
        # 注意，最后一个StageModule只输出分辨率最高的特征层
        self.stage4 = nn.Sequential(
            StageModule(input_branches=4, output_branches=4, c=base_channel),
            StageModule(input_branches=4, output_branches=4, c=base_channel),
            StageModule(input_branches=4, output_branches=1, c=base_channel)
        )

        # Final layer
        self.final_layer = nn.Conv2d(base_channel, num_joints, kernel_size=1, stride=1, bias=False)

        self.feature_3072 = nn.Conv2d(num_joints, 3072, kernel_size=1, stride=1, bias=False)

        self.output = nn.Conv2d(num_joints * 2, num_joints, kernel_size=1, stride=1, bias=False)

        # Heat_map

        self.groups = [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11], [12], [13], [14], [15], [16]]
        self.group_mode = group_mode
        self.normalize_heatmap = normalize_heatmap
        self.norm_scale = norm_scale
        self.fc_direct = nn.Linear(3072, 1, bias=False)
        self.bn_direct = nn.BatchNorm1d(3072)
        self.sigmoid = nn.Sigmoid()


        self.linked_edges = \
            [[0, 1], [0, 2], [1, 3], [2, 4], [5, 6], [5, 7], [6, 8], [7, 8], [7, 9], [8, 10], [9, 10], [11, 12], [11, 13],
             [12, 14], [13, 14], [13, 15], [14, 16], [15, 16]]
        self.gnn = GCN(3072, 3072, 3072, dropout=0.2)




    def normalize(self, in_tensor, norm_scale):
        n, c, h, w = in_tensor.shape
        in_tensor_reshape = in_tensor.reshape((n, c, -1))

        normalized_tensor = F.softmax(norm_scale * in_tensor_reshape, dim=2)
        normalized_tensor = normalized_tensor.reshape((n, c, h, w))

        return normalized_tensor

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu(x)

        x = self.layer1(x)
        x = [trans(x) for trans in self.transition1]  # Since now, x is a list

        x = self.stage2(x)
        x = [
            self.transition2[0](x[0]),
            self.transition2[1](x[1]),
            self.transition2[2](x[-1])
        ]  # New branch derives from the "upper" branch only

        x = self.stage3(x)
        x = [
            self.transition3[0](x[0]),
            self.transition3[1](x[1]),
            self.transition3[2](x[2]),
            self.transition3[3](x[-1]),
        ]  # New branch derives from the "upper" branch only

        x = self.stage4(x)

        x = self.final_layer(x[0])

        featuremap_cnn = x

        x = self.feature_3072(x)

        feature_map = x
        "===================一阶段===================="
        # 求热度图
        feature_maps = F.interpolate(feature_map, [64, 48], mode='bilinear', align_corners=False)
        n, c, h, w = feature_maps.shape

        x_reshaped = feature_maps.reshape((n, c, -1))
        idx = torch.argmax(x_reshaped, 2)
        max_response, _ = torch.max(x_reshaped, 2)

        idx = idx.reshape((n, c, 1))
        max_response = max_response.reshape((n, c))
        max_index = torch.empty((n, c, 2))
        max_index[:, :, 0] = idx[:, :, 0] % w  # column
        max_index[:, :, 1] = idx[:, :, 0] // w  # row

        if self.group_mode == 'sum':
            heatmap = torch.sum(feature_maps[:, self.groups[0]], dim=1, keepdim=True)
            max_response_2 = torch.mean(max_response[:, self.groups[0]], dim=1, keepdim=True)

            for i in range(1, len(self.groups)):
                heatmapi = torch.sum(feature_maps[:, self.groups[i]], dim=1, keepdim=True)
                heatmap = torch.cat((heatmap, heatmapi), dim=1)

                max_response_i = torch.mean(max_response[:, self.groups[i]], dim=1, keepdim=True)
                max_response_2 = torch.cat((max_response_2, max_response_i), dim=1)

        if self.normalize_heatmap:
            heatmap = self.normalize(heatmap, 1.0)
            a = heatmap.shape

        # 热度图与特征图相乘得到特征向量
        feature_vector_list = []
        for i in range(17 + 1):
            if i < 17:  # skeleton-based local feature vectors
                score_map_i = heatmap[:, i, :, :].unsqueeze(1).repeat([1, 3072, 1, 1])  # 16 2048 16 8
                #print(score_map_i.shape)
                feature_vector_i = torch.sum(score_map_i * feature_maps, [2, 3])
                #print(feature_vector_i.shape)
                feature_vector_list.append(feature_vector_i)
            else:  # global feature vectors
                feature_vector_i = (
                        F.adaptive_avg_pool2d(feature_maps, 1) + F.adaptive_max_pool2d(feature_maps, 1)).squeeze()
                feature_vector_list.append(feature_vector_i)

        batch = 2


        if featuremap_cnn.shape[0] == batch:
            cated_features = [feature.unsqueeze(1) for feature in feature_vector_list]
            cated_features = torch.cat(cated_features, dim=1)  # 16 14 2048
            # print(cated_features.shape)

            # 创建邻接矩阵
            self_connect = 1
            if self_connect > 0:
                adj = np.eye(17) * self_connect
            else:
                adj = np.zeros([17] * 2)

            for i, j in self.linked_edges:
                adj[i, j] = 1.0
                adj[j, i] = 1.0

            # we suppose the last one is global feature
            adj[-1, :-1] = 0
            adj[-1, -1] = 1
            # print(adj)

            adj = torch.from_numpy(adj.astype(np.float32))

            keypoint_feature = cated_features[:, :17, :]

            keypoint_feature_commen = (keypoint_feature.sum(dim=0) / batch)

            keypoint_feature_mean = (keypoint_feature.sum(dim=1) / 17).unsqueeze(1).repeat([1, 17, 1])

            similarity = F.cosine_similarity(keypoint_feature, keypoint_feature_mean, dim=2)

            distances_cos = torch.ones(batch, 17).cuda() - similarity

            distances_cos = distances_cos.unsqueeze(2).repeat([1, 1, 3072])
            keypoint_feature_commen = keypoint_feature_commen.unsqueeze(0).repeat([batch, 1, 1])
            cos_commen = distances_cos * keypoint_feature_commen
            keypoint_feature_after = keypoint_feature + cos_commen
            distances = torch.abs(keypoint_feature_after - keypoint_feature_mean)  # [bs, k, 2048],全局特征与各关键点之间的差异
            #print(distances.shape)

            distances_gap = []
            position_list = []
            for i, j in itertools.product(list(range(17)), list(range(17))):  # 14 * 14
                if i < j and (i != 16 and j != 16) and adj[i, j] > 0:
                    distances_gap.append(distances[:, i, :].unsqueeze(1) - distances[:, j, :].unsqueeze(1))
                    position_list.append([i, j])
            distances_gap = 16 * torch.cat(distances_gap, dim=1)  # [bs, edge_number, 2048]
            # print(distances_gap.shape)
            adj_tmp = self.sigmoid(self.fc_direct(
                self.bn_direct(distances_gap.transpose(1, 2)).transpose(1, 2))).squeeze()  # [bs, edge_number]
            # print(adj_tmp.shape)#16 16 之前定义好的16个边

            # re-assign
            adj2 = torch.ones([batch, 17, 17]).cuda()
            for indx, (i, j) in enumerate(position_list):
                adj2[:, i, j] = adj_tmp[:, indx] * 2
                adj2[:, j, i] = (1 - adj_tmp[:, indx]) * 2
            #print(adj2.shape)  # 16 14 14
            mask = adj.unsqueeze(0).repeat([batch, 1, 1]).cuda()
            #print(mask.shape)  # 16 14 14
            new_adj = adj2 * mask
            #print(new_adj.shape)
            new_adj = F.normalize(new_adj, p=1, dim=2)

            gnn_x = self.gnn(keypoint_feature_after, new_adj).reshape(batch, 17, 64, 48)

            out = torch.cat((featuremap_cnn, gnn_x), dim=1)

            output = self.output(out)

        else:
            batch = featuremap_cnn.shape[0]

            cated_features = [feature.unsqueeze(1) for feature in feature_vector_list]
            cated_features = torch.cat(cated_features, dim=1)  # 16 14 2048
            # print(cated_features.shape)

            # 创建邻接矩阵
            self_connect = 1
            if self_connect > 0:
                adj = np.eye(17) * self_connect
            else:
                adj = np.zeros([17] * 2)

            for i, j in self.linked_edges:
                adj[i, j] = 1.0
                adj[j, i] = 1.0

            # we suppose the last one is global feature
            adj[-1, :-1] = 0
            adj[-1, -1] = 1
            # print(adj)

            adj = torch.from_numpy(adj.astype(np.float32))

            keypoint_feature = cated_features[:, :17, :]

            keypoint_feature_commen = (keypoint_feature.sum(dim=0) / batch)

            keypoint_feature_mean = (keypoint_feature.sum(dim=1) / 17).unsqueeze(1).repeat([1, 17, 1])

            similarity = F.cosine_similarity(keypoint_feature, keypoint_feature_mean, dim=2)

            distances_cos = torch.ones(batch, 17).cuda() - similarity

            distances_cos = distances_cos.unsqueeze(2).repeat([1, 1, 3072])
            keypoint_feature_commen = keypoint_feature_commen.unsqueeze(0).repeat([batch, 1, 1])
            cos_commen = distances_cos * keypoint_feature_commen
            keypoint_feature_after = keypoint_feature + cos_commen
            distances = torch.abs(keypoint_feature_after - keypoint_feature_mean)  # [bs, k, 2048],全局特征与各关键点之间的差异
            #print(distances.shape)

            distances_gap = []
            position_list = []
            for i, j in itertools.product(list(range(17)), list(range(17))):  # 14 * 14
                if i < j and (i != 16 and j != 16) and adj[i, j] > 0:
                    distances_gap.append(distances[:, i, :].unsqueeze(1) - distances[:, j, :].unsqueeze(1))
                    position_list.append([i, j])
            distances_gap = 16 * torch.cat(distances_gap, dim=1)  # [bs, edge_number, 2048]
            # print(distances_gap.shape)
            adj_tmp = self.sigmoid(self.fc_direct(
                self.bn_direct(distances_gap.transpose(1, 2)).transpose(1, 2))).squeeze()  # [bs, edge_number]
            # print(adj_tmp.shape)#16 16 之前定义好的16个边

            # re-assign
            adj2 = torch.ones([batch, 17, 17]).cuda()
            for indx, (i, j) in enumerate(position_list):
                adj2[:, i, j] = adj_tmp[:, indx] * 2
                adj2[:, j, i] = (1 - adj_tmp[:, indx]) * 2
            #print(adj2.shape)  # 16 14 14
            mask = adj.unsqueeze(0).repeat([batch, 1, 1]).cuda()
            #print(mask.shape)  # 16 14 14
            new_adj = adj2 * mask
            #print(new_adj.shape)
            new_adj = F.normalize(new_adj, p=1, dim=2)

            gnn_x = self.gnn(keypoint_feature_after, new_adj).reshape(batch, 17, 64, 48)

            out = torch.cat((featuremap_cnn, gnn_x), dim=1)

            output = self.output(out)

        return output

