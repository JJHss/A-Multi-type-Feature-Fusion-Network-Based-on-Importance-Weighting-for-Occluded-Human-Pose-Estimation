from .HRNet_num_3 import HighResolutionNet
