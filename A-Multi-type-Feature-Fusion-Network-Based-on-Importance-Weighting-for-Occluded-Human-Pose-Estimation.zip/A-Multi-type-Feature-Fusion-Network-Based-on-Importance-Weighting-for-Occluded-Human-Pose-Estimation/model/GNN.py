import math
import torch
import torch.nn as nn
from torch.nn.modules.module import Module
from torch.nn.parameter import Parameter
from torch_scatter import scatter
import torch.nn.functional as F
from torch_geometric.nn.conv import MessagePassing


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nout, dropout, drop_rate=0):
        super(GCN, self).__init__()
        self.gc1 = nn.Linear(nfeat, nhid)
        self.gc2 = nn.Linear(nhid, nout)
        self.dropout = dropout
        self.drop_rate = drop_rate

    def forward(self, x, adj):
        # adj = keep_edge(adj, self.drop_rate)
        x = F.relu(self.gc1(adj @ x))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(adj @ x)
        return x


class GraphSAGE(torch.nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, drop_rate=0):
        super().__init__()
        self.gc1 = SAGEConvLayer(nfeat, nhid)
        self.gc2 = SAGEConvLayer(nhid, nclass)
        self.dropout = dropout
        self.drop_rate = drop_rate

    def forward(self, x, adj):
        adj = keep_edge(adj, self.drop_rate)
        adj = adj.to_sparse().indices()
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x


class Res_SAGE(nn.Module):
    def __init__(self, nfeat, nclass, nhid, nlayers=3, dropout=0.2, drop_rate=0):
        super(Res_SAGE, self).__init__()

        self.layers = nn.ModuleList()
        self.layers.append(SAGEConvLayer(nhid, nhid))       # SAGEConvLayer => GraphConvolution
        for l in range(1, nlayers):
            self.layers.append(SAGEConvLayer(nhid, nhid))
        self.input_fc = nn.Linear(nfeat, nhid)
        self.predict = nn.Linear(nhid, nclass)
        self.res_coefficient = 0.2
        self.last_layer_coefficient = 0.5
        self.res_weights = torch.nn.Parameter(torch.randn(nlayers))
        self.drop_rate = drop_rate

    def forward(self, h, adj):      # 很多GNN， 第一层->第二层，第二层到第三层的时候：1*0.2 + 2
        adj = keep_edge(adj, self.drop_rate)
        adj = adj.to_sparse().indices()     # GraphConvolution 的时候，把这句话给注释掉
        h = self.input_fc(h)
        h_input = h
        layer_h_out = []        # Save h for each layer
        layer_i = 0
        for gnn in self.layers:
            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()
            h = gnn(h, adj)
            if layer_i == 0:
                h = h + self.res_coefficient * h_input
            else:
                h = h + self.res_coefficient * h_input + self.last_layer_coefficient * layer_h_out[layer_i-1]

            layer_h_out.append(h)

            if hasattr(torch.cuda, 'empty_cache'):
                torch.cuda.empty_cache()

        weight = F.softmax(self.res_weights, dim=0)
        for i in range(len(layer_h_out)):
            layer_h_out[i] = layer_h_out[i] * weight[i]

        h = sum(layer_h_out)

        return h


def keep_edge(adj, drop_rate):
    if drop_rate == 0:
        pass
    else:
        mask = torch.rand((adj.shape[0], adj.shape[0]))
        mask = mask > drop_rate
        adj = adj * mask.to("cuda")
    return adj


class GraphConvolution(Module):

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class SAGEConvLayer(MessagePassing):
    def __init__(self, nfeat, nclass, bias=True, **kwargs):
        kwargs.setdefault('aggr', 'mean')
        super().__init__(**kwargs)

        self.nfeat = nfeat
        self.nclass = nclass

        self.linear_neighbors = nn.Linear(nfeat, nclass, bias=True)
        self.linear_self = nn.Linear(nfeat, nclass, bias=False)

        self.reset_parameters()          # Reset Parameters

    def reset_parameters(self):
        self.linear_neighbors.reset_parameters()
        self.linear_self.reset_parameters()

    def forward(self, x, edge_index, size=None):

        x = (x, x)      # The first is to update, the second is kept

        # Aggregate Neighbors
        out = self.propagate(edge_index, x=x, size=size)
        out = self.linear_neighbors(out)

        # Self Embeddings
        x_r = x[1]
        out += self.linear_self(x_r)

        # Normalize Layer
        out = F.normalize(out, dim=-1)

        return out


class NEW_SAGEConvLayer(Module):
    def __init__(self, nfeat, nclass):
        super(NEW_SAGEConvLayer, self).__init__()
        self.nfeat = nfeat
        self.nclass = nclass

        self.linear_neighbors = nn.Linear(nfeat, nclass, bias=True)
        self.linear_self = nn.Linear(nfeat, nclass, bias=False)

        self.reset_parameters()          # Reset Parameters
        self.Propagate = Propagate(nfeat, nfeat)

    def reset_parameters(self):
        self.linear_neighbors.reset_parameters()
        self.linear_self.reset_parameters()

    def forward(self, x, edge_index, size=None):

        x = (x, x)      # The first is to update, the second is kept

        # Aggregate Neighbors
        # out = self.propagate(edge_index, x=x, size=size)
        out = self.Propagate(edge_index=edge_index, x=x)
        out = self.linear_neighbors(out)

        # Self Embeddings
        x_r = x[1]
        out += self.linear_self(x_r)

        # Normalize Layer
        out = F.normalize(out, dim=-1)

        return out


class Propagate(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Propagate, self).__init__()
        self.lin = nn.Linear(in_channels, out_channels)

    def forward(self, x, edge_index):
        return self.propagate(x, edge_index)

    def propagate(self, x, edge_index):
        edge_index = self.add_self_loops(edge_index, num_nodes=x[0].shape[0])
        out = self.message(x[0], edge_index)
        out = self.aggregate(out, edge_index)
        out = self.update(out)

        return out

    def message(self, x, edge_index):
        x = self.lin(x)

        row, col = edge_index
        deg = self.degree(col, x.size(0), dtype=x.dtype)
        deg_inv_sqrt = deg.pow(-0.5)
        norm = deg_inv_sqrt[row] * deg_inv_sqrt[col]

        x_j = x[row]
        x_j = norm.view(-1, 1) * x_j

        return x_j

    def aggregate(self, x_j, edge_index):
        row, col = edge_index
        aggr_out = scatter(x_j, col, dim=-2, reduce='sum')
        return aggr_out

    def update(self, aggr_out):
        return aggr_out

    def degree(self, index, num_nodes, dtype):
        N = num_nodes
        out = torch.zeros((N,), dtype=dtype, device=index.device)
        one = torch.ones((index.size(0),), dtype=out.dtype, device=out.device)
        return out.scatter_add_(0, index, one)

    def add_self_loops(self, edge_index, num_nodes):
        N = num_nodes
        loop_index = torch.arange(0, N, dtype=torch.long, device=edge_index.device)
        loop_index = loop_index.unsqueeze(0).repeat(2, 1)

        edge_index = torch.cat([edge_index, loop_index], dim=1)
        return edge_index